package com.cloacalandia.processing

import java.sql.Timestamp

import org.apache.commons.lang3.StringUtils
import org.apache.log4j.{Level, Logger}
import org.apache.spark.{SparkContext, sql}
import org.apache.spark.graphx.{Edge, Graph, VertexId}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.StreamingQueryListener.{QueryProgressEvent, QueryStartedEvent, QueryTerminatedEvent}
import org.apache.spark.sql.streaming.{StreamingQueryListener, Trigger}
import org.apache.spark.sql.types._

import scala.io.Source

object MessageSpy {
  //case class IOT_Message(EventTime: Timestamp, MessageId: Long, Message: String, IOT_Id: String, ScrUserId: Long, DstUserId: Long)
  case class WordCounter(word: String, count: Long)

  def main(args: Array[String]): Unit = {
    Logger.getLogger("org").setLevel(Level.ERROR)
    val log = Logger.getLogger(getClass.getName)

    // Levantamos sesion de Spark
    val spark = SparkSession
      .builder()
      .appName(name = "Message Spy")
      .master(master = "local[*]") // utiliza todos los cores de la máquina local
      .getOrCreate()

    // Configuro el sistema para utilizar el timezone UTC. Considerando que las horas enviadas por los distpositivos IOT
    // son UTC y que a la hora de hacer las agregaciones las haremos tambien en UTC.
    spark.conf.set("spark.sql.session.timeZone", "UTC")

    // Recomendación en algunos libros para que en una maquina local no se generen demasiadas particiones que puedan empeorar
    // el rendimiento.
    spark.conf.set("spark.sql.shuffle.partitions", "4")

    import spark.implicits._
    /************************************************************************
         Fuentes de datos (Blacklist, Users, Kakfa)
     ***********************************************************************/
    // Cargar las palabras prohibidas desde el fichero blacklist_words.txt
    // En este caso es una pequeña operacion que se realizará sobre el top 10 de palabras detectadas durante una ventana
    // de una hora, de modo que será una operación local al driver.
    val blackListWords = Source.fromFile("datasets/blacklist_words.txt").getLines().toSet

    // ========== DF con USERS ==========
    val userSchema = new StructType()
      .add("UserId", "string")
      .add("Name", "string")
      .add("LastName", "string")
      .add("Age", "integer")
      .add("Sex", "String")

    // Crear un DF leyendo un CSV y pasando el esquema
    val usersDF= spark.read.format("csv")
      .option("header",true)
      .schema(userSchema)
      .load("datasets/users.txt")

    //usersDF.show()

    // ========== DF con STOPWORDS ==========
    val stopWords = spark.read.format("csv")
      .option("inferSchema","true")
      .load("datasets/stopwords.txt")

    val stopWordsBroadcast = spark.sparkContext.broadcast(stopWords.map(row=>row.getAs[String](0)).collect.toSet)

    // ========== DF stream KAFKA ==========
    // Leer de Kafka.Con kafka con podemos configurar el schema directamente ya que tiene uno fijo (key, value)
    val messagesDF = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "iot")
      //.option("includeTimestamp", true)
      .option("startingOffsets", "latest") //.option("startingOffsets", "earliest") \
      .load()
      .selectExpr("CAST(value AS STRING)")
      .map(parseKafkaMessage)
      .toDF("EventTime","MessageId","Message","IOT_Id","SrcUserId","DstUserId")

    // debug
    println(s"Is streaming: ${messagesDF.isStreaming}")
    messagesDF.printSchema
    //messagesDF.describe().show()

    /************************************************************************
         Limpiar y preparar datos
     ***********************************************************************/
    // Rellenaré un dataframe con todos los datos que nos pueden ser utililes
    // Timestamp, mensaje y usuarios

    // Eliminamos las duplcidades que puederan haber de mensajes capturados (consideramos MessageId como el identificador
    // único para todos los mensajes de la red)
    //val messagesWithoutDuplicitiesDF = messagesDF.dropDuplicates("MessageId").withWatermark("EventTime","5 minutes")

    // Extraemos las palabras de cada uno de los mensajes
    // Aplicamos la función de Processado de mensajes
    val wordsDF = messagesDF.select($"Message", $"EventTime").as[(String,Timestamp)]
      .flatMap(tupla=>processMessage(tupla._1, stopWordsBroadcast.value)
        .map(word=>(word, tupla._2)))
      .toDF("Word","EventTime")

    /************************************************************************
         Output Sinks
     ***********************************************************************/
    // ========== DF con la agregación por ventana temporal ==========
    val aggWords = wordsDF
      .withWatermark("EventTime", "10 minute") // maximo retraso
      .groupBy(window($"EventTime", "1 minute"), $"Word")
      .count()
      //.sort(desc("count"))
      //.limit(10)
    aggWords.printSchema

    // Print updated aggregations to console
    val query = aggWords.select($"window.start" as("startTime"), $"*")
      .writeStream
      .outputMode("update")
      .trigger(Trigger.ProcessingTime("1 minute")) // cada cuando escribe
      .format("console")
      .option("truncate", "false") //prevent trimming output fields
      .start()

    // Have all the aggregates in an in-memory table
    /*aggWords
      .writeStream
      .queryName("agg_words")    // this query name will be the table name
      .outputMode("update")
      .trigger(Trigger.ProcessingTime("1 minute"))
      .format("memory")
      .start()*/

    val queryToFile = aggWords
      .select($"window.start" as("startTime"), $"Word", $"count")
      .withColumn("year", year(col("startTime")))
      .withColumn("month", month(col("startTime")))
      .withColumn("day", dayofmonth(col("startTime")))
      .withColumn("hour", hour(col("startTime")))
      .writeStream
      .queryName("Persist aggregated words")
      .outputMode("append")
      .format("parquet")
      //.format("csv")
      .option("path", "output/agg_words_result")
      .option("checkpointLocation", "checkpoint")
      .trigger(Trigger.ProcessingTime("1 minute")) // cada cuando escribe
      .partitionBy("year", "month","day", "hour")
      .option("truncate", false)
      .start()

    /************************************************************************
    Prueba realizado con los Listeners asíncronos

    Mi idea era la de detectar el procesado de un micro-batch del streamWriter a memoria y sobre ese hacer una query
    para detectar si dentro del top 10 se encontraban las palabras prohibidas y en consecuencia había que enviar una
    notificación
    ************************************************************************/
    spark.streams.addListener(new StreamingQueryListener() {
      override def onQueryStarted(queryStarted: QueryStartedEvent): Unit = {
        println("Query started: " + queryStarted.id)
      }
      override def onQueryTerminated(queryTerminated: QueryTerminatedEvent): Unit = {
        val q =spark.streams.get(queryTerminated.id)
        //queryTerminated.id
        println("Query terminated: " + queryTerminated.id)
      }
      override def onQueryProgress(queryProgress: QueryProgressEvent): Unit = {

        val q = spark.streams.get(queryProgress.progress.id)
        val progress = queryProgress.progress
        if(q.name == "agg_words"){
          println(s"La query ha terminado un micro-batch id = ${progress.batchId} (${progress.durationMs} sec), ${progress.eventTime}")
          spark.sql("select * from agg_words order by count desc limit 10").show(false)

          val words = spark.sql("select * from agg_words order by count desc limit 10")
            .collect()
            .map(r=>WordCounter(r.getString(1),r.getLong(2)))

          val alerts = words.filter(w=>blackListWords.contains(w.word))

          if(alerts.size>0){
            sendNotification(alerts)
          }
        }
      }
    })

    spark.streams.awaitAnyTermination() //running multiple streams at a time

  }

  // TODO Faltaría añadir protección por si llegan datos con formato incorrecto
  def parseKafkaMessage(row:Row)={
    val fields = row.getString(0).split(",")
    (Timestamp.valueOf(fields(0)), fields(1).toLong, fields(2).toString, fields(3).toString, fields(4).toLong, fields(5).toLong)
  }

  // Función para el procesado de los mensajes
  //   - Decodifica los mensajes (simulado)
  //   - Elimina los acentos de las palabras y las convierte a minúsculas.
  //   - Separa los mensajes en palabras.
  //   - Filtra las palabras que tenemos en las lista de stopwords.
  def processMessage(message: String, stopWords: Set[String]) = {

    val decodedMessage = decodeMessage(message)
    StringUtils.stripAccents(decodedMessage)
      .toLowerCase()
      .split("\\W+")
      .filter(!stopWords.contains(_)).toSeq
  }

  def decodeMessage(message:String)={
    message
  }

  // Simula en envío de notificaciones de alarma
  def sendNotification(counters: Array[WordCounter]): Unit =
  {
    for (elem <- counters) {
      println(s"ALERTA!! palabra ${elem.word} detectada ${elem.count} veces")
    }
  }

  //TODO Faltatia rellenar los edge con los usuarios origen y destino detectados en los mensajes capturados
  def GraphxProcess(spark: SparkSession, usersDF: sql.DataFrame)={
    /***********************************************
                          GRAPHX
     ***********************************************/
    import spark.implicits._
    val sc: SparkContext = spark.sparkContext
    // Create an RDD for the vertices
    // (ID_NODO, tupla de propiedades)
    val users: RDD[(VertexId, (String, String))] =usersDF.map(row=>(row.getLong(0),(row.getString(2), row.getString(3)))).rdd

    // Create an RDD for edges
    val relationships: RDD[Edge[String]] =
      sc.parallelize(Array(Edge(3L, 7L, "collab"), Edge(5L, 3L, "advisor"),
        Edge(2L, 5L, "colleague"), Edge(5L, 7L, "pi")))
    // Define a default user in case there are relationship with missing user
    val defaultUser = ("John Doe", "Missing")
    // Build the initial Graph
    val graph = Graph(users, relationships, defaultUser)

  }
}